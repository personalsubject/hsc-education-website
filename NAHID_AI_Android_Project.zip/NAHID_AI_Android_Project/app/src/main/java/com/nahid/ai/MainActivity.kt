package com.nahid.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    private val requestCode = 41
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 13, 24)
        window.navigationBarColor = Color.rgb(12, 13, 24)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 42, 28, 28)
            setBackgroundColor(Color.rgb(12, 13, 24))
        }
        val title = TextView(this).apply {
            text = "NAHID AI"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val sub = TextView(this).apply {
            text = "YOUR VOICE. YOUR PHONE. YOUR CONTROL."
            textSize = 11f
            setTextColor(Color.rgb(190, 120, 255))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 28)
        }
        status = TextView(this).apply {
            text = "Status: Wake Word বন্ধ"
            textSize = 16f
            setTextColor(Color.rgb(220, 220, 235))
            gravity = Gravity.CENTER
            setPadding(12, 18, 12, 24)
        }
        root.addView(title)
        root.addView(sub)
        root.addView(status)

        root.addView(makeButton("🎙  Hey Nahid চালু করো") { requestAndStart() })
        root.addView(makeButton("■  Wake Word বন্ধ করো") {
            stopService(Intent(this, WakeWordService::class.java))
            status.text = "Status: Wake Word বন্ধ"
        })
        root.addView(makeButton("⚙  অ্যাপ পারমিশন সেটিংস") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                android.net.Uri.parse("package:$packageName")))
        })
        val note = TextView(this).apply {
            text = "Wake Word চালু থাকলে একটি স্থায়ী নোটিফিকেশন থাকবে। মাইক্রোফোন ব্যবহারের অনুমতি ছাড়া এটি শুনবে না। কলের জন্য CALL_PHONE এবং কন্টাক্ট খোঁজার জন্য Contacts অনুমতি লাগবে।"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(4, 28, 4, 0)
        }
        root.addView(note)
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(100, 48, 170)))
            setOnClickListener { action() }
            val p = LinearLayout.LayoutParams(-1, -2)
            p.setMargins(0, 10, 0, 10)
            layoutParams = p
        }

    private fun requestAndStart() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)
            permissions.add(Manifest.permission.CALL_PHONE)
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            permissions.add(Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)

        if (permissions.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) {
            requestPermissions(permissions.toTypedArray(), requestCode)
        } else startWakeService()
    }

    private fun startWakeService() {
        val i = Intent(this, WakeWordService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        status.text = "Status: Hey Nahid শুনছে (নোটিফিকেশন চালু থাকবে)"
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == this.requestCode) {
            if (results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) {
                startWakeService()
            } else status.text = "মাইক্রোফোন অনুমতি দেওয়া হয়নি"
        }
    }
}
