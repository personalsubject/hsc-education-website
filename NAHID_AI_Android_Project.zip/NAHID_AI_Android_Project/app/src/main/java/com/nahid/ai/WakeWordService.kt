package com.nahid.ai

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.speech.*
import java.util.Locale

class WakeWordService : Service() {
    private var recognizer: SpeechRecognizer? = null
    private lateinit var manager: AudioManager
    private val channelId = "nahid_ai_voice"
    private var restarting = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        manager = getSystemService(AUDIO_SERVICE) as AudioManager
        createChannel()
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("NAHID AI সক্রিয়")
            .setContentText("Wake Word: “Hey Nahid” শুনছে। বন্ধ করতে অ্যাপ খুলুন।")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        startForeground(7, notification)
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            stopSelf()
            return
        }
        startRecognition()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "NAHID AI Voice", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun startRecognition() {
        if (restarting) return
        restarting = true
        Handler(Looper.getMainLooper()).post {
            try {
                recognizer?.destroy()
                recognizer = SpeechRecognizer.createSpeechRecognizer(this)
                recognizer?.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onError(error: Int) { scheduleRestart() }
                    override fun onResults(results: Bundle?) {
                        val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()?.lowercase(Locale.ROOT).orEmpty()
                        handlePhrase(heard)
                        scheduleRestart()
                    }
                    override fun onPartialResults(partialResults: Bundle?) {
                        val heard = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()?.lowercase(Locale.ROOT).orEmpty()
                        if (heard.contains("hey nahid") || heard.contains("হেই নাহিদ")) {
                            manager.playSoundEffect(AudioManager.FX_KEY_CLICK)
                        }
                    }
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                }
                recognizer?.startListening(intent)
            } catch (_: Exception) { scheduleRestart() }
        }
    }

    private fun scheduleRestart() {
        restarting = false
        Handler(Looper.getMainLooper()).postDelayed({ if (restarting.not()) startRecognition() }, 900)
    }

    private fun handlePhrase(text: String) {
        val wake = text.contains("hey nahid") || text.contains("হেই নাহিদ") || text.contains("হে নাহিদ")
        if (wake) {
            val command = text.substringAfter("hey nahid", text.substringAfter("হেই নাহিদ", "")).trim()
            if (command.isNotBlank()) runCommand(command)
            else updateNotification("Hey Nahid শনাক্ত হয়েছে। এবার নির্দেশ বলুন।")
            return
        }
        // Allow commands only when wake phrase is included in the same recognition result.
    }

    private fun runCommand(command: String) {
        when {
            command.contains("alarm") || command.contains("অ্যালার্ম") -> {
                val hour = Regex("(\\d{1,2})").find(command)?.value?.toIntOrNull()
                if (hour != null && hour in 0..23) {
                    val i = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                        putExtra(AlarmClock.EXTRA_HOUR, hour)
                        putExtra(AlarmClock.EXTRA_MINUTES, 0)
                        putExtra(AlarmClock.EXTRA_MESSAGE, "NAHID AI")
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try { startActivity(i) } catch (_: Exception) { updateNotification("অ্যালার্ম অ্যাপ পাওয়া যায়নি") }
                } else updateNotification("সময়টি বুঝতে পারিনি। যেমন: Hey Nahid alarm 6")
            }
            command.contains("youtube") || command.contains("ইউটিউব") || command.contains("ভিডিও") -> {
                val query = command.replace("youtube", "").replace("ইউটিউব", "").replace("ভিডিও", "").trim()
                val url = if (query.isBlank()) "https://www.youtube.com" else
                    "https://www.youtube.com/results?search_query=" + Uri.encode(query)
                openUrl(url)
            }
            command.contains("call") || command.contains("কল") || command.contains("ফোন") -> {
                val name = command.replace("call", "").replace("কল", "")
                    .replace("ফোন দাও", "").replace("ফোন করো", "").trim()
                if (name.isBlank()) { updateNotification("কাকে কল করব? নাম বলুন।"); return }
                callContact(name)
            }
            else -> updateNotification("নির্দেশ বুঝতে পারিনি। কল, অ্যালার্ম বা YouTube বলুন।")
        }
    }

    private fun callContact(name: String) {
        if (checkSelfPermission(android.Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            updateNotification("কল ও Contacts অনুমতি অ্যাপ থেকে চালু করুন")
            return
        }
        val cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        )
        val matches = mutableListOf<String>()
        cursor?.use { while (it.moveToNext()) matches.add(it.getString(0)) }
        val distinct = matches.distinct()
        if (distinct.size == 1) {
            try {
                val call = Intent(Intent.ACTION_CALL, Uri.parse("tel:${distinct[0]}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(call)
                updateNotification("$name-কে কল করা হচ্ছে")
            } catch (_: Exception) { updateNotification("কল শুরু করা যায়নি") }
        } else if (distinct.isEmpty()) updateNotification("$name নামে কন্টাক্ট পাওয়া যায়নি")
        else updateNotification("একাধিক নম্বর পাওয়া গেছে। আগে কন্টাক্ট মিলিয়ে নিন।")
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) { updateNotification("YouTube বা ব্রাউজার পাওয়া যায়নি") }
    }

    private fun updateNotification(message: String) {
        val n = Notification.Builder(this, channelId)
            .setContentTitle("NAHID AI")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true).build()
        getSystemService(NotificationManager::class.java).notify(7, n)
    }

    override fun onDestroy() {
        recognizer?.destroy()
        recognizer = null
        super.onDestroy()
    }
}
